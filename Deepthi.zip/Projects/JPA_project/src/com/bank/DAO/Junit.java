package com.bank.DAO;

import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;

import org.junit.Test;

import com.bank.Entity.Account;

public class Junit {
	EntityManager em;
	DataBase db=new DataBase();
	
	

	//Hashmap which is storing all account holders information
	Account bb1;					//object of Bankbean class

	@Test// getting Balance of account holder by reference to their accno
	public void getBalance() { 

		em = db.getConnection();
		em.getTransaction().begin();
		Account emp1=(Account) em.find(Account.class,new Long(100000001));
		em.getTransaction().commit();
		long observed= emp1.getBalance();
		long expected=1000;
		assertEquals(expected, observed);
		
	}

	


}

