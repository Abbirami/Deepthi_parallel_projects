package com.bank.DAO;



import com.bank.Entity.Account;



public interface BankDAOI {
	
	long getBalance(long accNo) ;

	void setBalance(long accNo, long bal, String st);


	boolean checkPassword(String str,long accNo) ;

	boolean checkAccNo(long accNo);

	long setData(Account bb);

	String getTransaction(long accNo);

	
}
