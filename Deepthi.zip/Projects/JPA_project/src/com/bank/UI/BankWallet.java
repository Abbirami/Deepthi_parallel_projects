package com.bank.UI;


import java.sql.SQLException;
import java.util.Scanner;

import com.bank.Entity.Account;

import com.bank.Service.BankService;
import com.bank.Service.BankServiceI;

//This creates a user interface for user so that the user can connect with database
public class BankWallet {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in); // Scanner Object for Taking Input from User
		BankService bs = new BankService();
		int i = 1001;
		while (true) {			
            System.out.println("XYZ BANK");
            System.out.println("PAYMENT WALLET");
			System.out.println(
					" 1. Create Account \n 2. Show Balance \n 3. Deposit \n 4. Withdraw \n 5. Fund Transfer \n 6. Print Transaction \n 7.Exit \n \n******* \n");
			System.out.print("    Enter Your Choice : ");

			int key = sc.nextInt();
			switch (key) {
			
			case 1:
				System.out.print("    Enter your name : ");
				String name = sc.next();
				name += sc.nextLine();
				while (!bs.checkName(name)) {

					System.out.print("    Enter your name : ");
					name = sc.next();
					name += sc.nextLine();
				}

				System.out.print("    Enter your Phone number : ");
				long mob = sc.nextLong();
				while (!bs.checkM(mob)) {
					System.out.print("    Enter your Phone number : ");
					mob = sc.nextLong();
				}

				System.out.print("    Enter a password :");
				String password = sc.next();
				while (!bs.checkP(password)) {
					System.out.print("    Enter a password :");
					password = sc.next();
				}
				String st = bs.addAccount(name, mob, password);
				i++;
				System.out.print("    " + st +"\n");

				break;
			case 2:
				System.out.print("    Enter Your Account number : ");
				long accNo = sc.nextLong();
				if (bs.checkAccNo(accNo)) {
					System.out.print("    Enter your Password : ");
					String pass = sc.next();
					if (bs.checkPass(pass,accNo)) {
						long bal = bs.getBalance(accNo);
						System.out.print("    Your account balance is : Rs." + bal + "\n");
					}
				}

				break;
			case 3:
				System.out.print("    Enter Your Account number : ");
				accNo = sc.nextLong();
				if (bs.checkAccNo(accNo)) {
					System.out.print("    Enter your Password : ");
					String pass = sc.next();
					if (bs.checkPass(pass,accNo)) {

						System.out.print("    Enter the amount you need to deposit : Rs.");
						long bal1 = sc.nextInt();
						long bal = bs.getBalance(accNo) + bal1;

						bs.setBalance(accNo, bal, "\n    TransID : " + i + "       Amount credited  Rs." + bal1);
						i++;
						System.out.print("    Amount You deposited is Rs." + bal1 + "\n");
						System.out.print("    Total balance is Rs." + bs.getBalance(accNo) + "\n");

					}
				}
				break;
			case 4:
				System.out.print("    Enter Your Account number : ");
				accNo = sc.nextLong();
				if (bs.checkAccNo(accNo)) {
					System.out.print("    Enter your Password : ");
					String pass = sc.next();
					if (bs.checkPass(pass,accNo)) {

						System.out.print("    Enter the amount you need to  withdraw : Rs.");
						long bal1 = sc.nextInt();
						long bal = bs.getBalance(accNo) - bal1;
						bs.setBalance(accNo, bal, "\n    TransID : " + i + "       Amount debited    Rs." + bal1);
						System.out.print("    Amount You withdraw is Rs." + bal1 + "\n");
						System.out.print("    Total balance is Rs." + bs.getBalance(accNo) + "\n");
						i++;
					}
				}
				break;
			case 5:
				System.out.print("    Enter Your Account number : ");
				accNo = sc.nextLong();
				if (bs.checkAccNo(accNo)) {
					System.out.print("    Enter your Password : ");
					String pass = sc.next();
					if (bs.checkPass(pass,accNo)) {
						System.out.print("    Enter Account number to which you want to transer fund : ");
						long accNo1 = sc.nextLong();
						if (bs.checkAccNo(accNo1)) {
							long bal = bs.getBalance(accNo);
							long bal1 = bs.getBalance(accNo1);

							System.out.print("    Enter the amount to be transferred : Rs.");
							long bal2 = sc.nextInt();
							bs.setBalance(accNo, bal - bal2, "\n    TransID : " + i + "       Amount debited    Rs."
									+ bal2 + "  to Account Number " + accNo1);
							bs.setBalance(accNo1, bal1 + bal2, "\n    TransID : " + i + "        Amount credited  Rs."
									+ bal2 + "  from Account Number " + accNo);
							System.out.print("    Amount You transferred is Rs." + bal2 + "\n");
							System.out.println("    Total balance is Rs." + bs.getBalance(accNo) + "\n");
							i++;
						}
					}
				}
				break;
			case 6:
				System.out.print("    Enter Your Account number : ");
				accNo = sc.nextLong();
				if (bs.checkAccNo(accNo)) {
					System.out.print("    Enter your Password : ");
					String pass = sc.next();
					if (bs.checkPass(pass,accNo)) {
						System.out.print("Transaction Details");
						String strn = bs.getTransaction(accNo);
						System.out.print("    " + strn + "\n");
						System.out.print("    Total balance is Rs." + bs.getBalance(accNo) + "\n");

					}
				}
				break;
			
			case 7:
				System.exit(0);
			default:
				System.out.println("    Enter Valid choice : ");
				break;

			}

		}
	}
}